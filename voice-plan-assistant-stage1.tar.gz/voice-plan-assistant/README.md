# 語音計畫助理

Go + Vue 3 (Vant) 單一服務。階段 1:骨架與 Google 登入(單一帳號白名單)。

## 本機開發

```bash
cp .env.example .env        # 填好後用 `set -a; . ./.env; set +a` 載入
go mod tidy                 # 第一次:產生 go.sum,之後請提交
go run ./cmd/server         # :8080
cd web && pnpm install && pnpm dev   # :5173,已代理 /api 與 /auth
```

本機測試登入時,`OAUTH_REDIRECT_URL=http://localhost:8080/auth/callback`、`APP_BASE_URL=http://localhost:8080`,並在 Google Cloud 加上同一個 redirect URI。

## 測試

```bash
go test ./...
# 含資料庫整合測試(請用拋棄式資料庫):
TEST_DATABASE_URL=postgresql://... go test ./internal/auth/
```

## 部署到 Railway

1. Railway 新增服務(連結此 repo)與一個 Postgres。服務會使用 `Dockerfile` 與 `railway.json`(單實例、`/healthz` 健康檢查)。
2. Google Cloud Console → API 與服務 → 憑證 → 建立「OAuth 用戶端 ID」(網頁應用程式),重新導向 URI 填 `https://<服務網域>/auth/callback`。
3. 在 Railway 服務填入 `.env.example` 內所有變數。`DATABASE_URL` 用參照 Postgres 服務的變數。
4. 部署後開 `https://<服務網域>/healthz` 應回 `ok`;用 `ALLOWED_EMAIL` 的帳號登入。
5. iPhone:Safari 開網址 → 分享 → 加入主畫面。

## 驗收清單(階段 1)

- 白名單帳號可登入,重新整理後仍保持登入。
- 其他 Google 帳號登入後看到「沒有使用權限」,資料庫 `users` 沒有新增資料。
- 未登入呼叫 `GET /api/me` 回 401。
- 登出後 cookie 被清除,`/api/me` 回 401。
- 加到 iPhone 主畫面後可開啟,且保持登入。
