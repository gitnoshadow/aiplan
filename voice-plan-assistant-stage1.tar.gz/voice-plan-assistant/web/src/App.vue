<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { showToast } from 'vant'

type State = 'loading' | 'anon' | 'authed'
const state = ref<State>('loading')
const email = ref('')
const errorText = ref('')

const ERRORS: Record<string, string> = {
  forbidden: '這個 Google 帳號沒有使用權限。請改用指定的帳號登入。',
  failed: '登入沒有完成,請再試一次。',
}

async function loadMe() {
  try {
    const res = await fetch('/api/me', { credentials: 'same-origin' })
    if (res.ok) {
      email.value = (await res.json()).email
      state.value = 'authed'
      return
    }
  } catch {
    showToast('無法連線到伺服器')
  }
  state.value = 'anon'
}

async function logout() {
  await fetch('/auth/logout', { method: 'POST', credentials: 'same-origin' })
  email.value = ''
  state.value = 'anon'
}

onMounted(() => {
  const code = new URLSearchParams(location.search).get('error')
  if (code) {
    errorText.value = ERRORS[code] ?? ERRORS.failed
    history.replaceState(null, '', '/')
  }
  loadMe()
})
</script>

<template>
  <main v-if="state === 'anon'" class="login">
    <div class="login-body">
      <h1>語音計畫助理</h1>
      <p class="lead">說出你的計畫,確認後寫進 Google 行事曆,時間到了用 LINE 提醒你和家人。</p>
      <p v-if="errorText" class="error" role="alert">{{ errorText }}</p>
    </div>
    <van-button type="primary" block round size="large" tag="a" href="/auth/login">
      使用 Google 登入
    </van-button>
  </main>

  <div v-else-if="state === 'authed'" class="home">
    <van-nav-bar title="計畫">
      <template #right>
        <van-button size="small" plain @click="logout">登出</van-button>
      </template>
    </van-nav-bar>
    <van-empty description="還沒有計畫。輸入計畫的功能即將開放。" />
    <p class="who">{{ email }}</p>
  </div>
</template>

<style scoped>
.login {
  min-height: 100%;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: calc(var(--safe-top) + 20vh) 24px calc(var(--safe-bottom) + 32px);
}
.login-body { max-width: 20rem; }
h1 { font-size: 2rem; line-height: 1.25; margin: 0 0 1rem; letter-spacing: 0.02em; }
.lead { font-size: 1rem; line-height: 1.7; margin: 0; opacity: 0.8; }
.error {
  margin: 1.5rem 0 0;
  padding-left: 0.75rem;
  border-left: 3px solid var(--signal);
  line-height: 1.6;
}
.home { padding-top: var(--safe-top); }
.who { text-align: center; font-size: 0.8rem; opacity: 0.55; margin: 0; }
</style>
