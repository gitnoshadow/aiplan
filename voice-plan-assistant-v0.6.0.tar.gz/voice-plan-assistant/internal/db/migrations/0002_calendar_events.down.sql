DROP TABLE IF EXISTS events;
DROP TABLE IF EXISTS google_credentials;
